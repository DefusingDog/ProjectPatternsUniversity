﻿using System;
using ObserverLab.Widgets;

namespace ObserverLab
{
    class Program
    {
        static void Main(string[] args)
        {
            var mchsDept = new MCHS();

            var cell = new CELLPHONES();
            var tv = new TELEVISION();
            var public_warning_network = new PWN();

            mchsDept.subObserver(cell);
            mchsDept.subObserver(tv);
            mchsDept.subObserver(public_warning_network);

            Console.WriteLine();

            mchsDept.notifyObservers();

            Console.ReadKey();

            mchsDept.desubObserver(tv);

            mchsDept.notifyObservers();

            Console.ReadKey();

        }
    }
}
