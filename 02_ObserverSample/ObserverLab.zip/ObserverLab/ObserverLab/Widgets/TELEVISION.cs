﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObserverLab.Widgets
{
    class TELEVISION : iObserver
    {
        private string tv;
        public void Display()
        {
            Console.WriteLine("ПО ТВ ПЕРЕДАЮТ: {0}", tv);
            Console.WriteLine("__________________________________");
        }

        public void Update(string SMS, string PWN, string TV)
        {
            tv = TV;
            Display();
        }
    }
}
