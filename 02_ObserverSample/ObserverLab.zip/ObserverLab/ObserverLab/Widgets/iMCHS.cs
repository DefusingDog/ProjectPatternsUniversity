﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObserverLab.Widgets
{
    public interface iMCHS
    {
        void subObserver(iObserver observer);
        void desubObserver(iObserver observer);
        void notifyObservers();
    }
}
