﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObserverLab.Widgets
{
    public interface iObserver
    {
        void Display();
        void Update(string SMS, string PWN, string TV);
    }
}
