﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObserverLab.Widgets
{
    class CELLPHONES : iObserver
    {
        private string sms;
        public void Display()
        {

            Console.WriteLine("БЗЗЗЗ, БЗЗЗЗ: {0}", sms);
            Console.WriteLine("__________________________________");
        }

        public void Update(string SMS, string PWN, string TV)
        {
            sms = SMS;
            Display();
        }
    }
}
