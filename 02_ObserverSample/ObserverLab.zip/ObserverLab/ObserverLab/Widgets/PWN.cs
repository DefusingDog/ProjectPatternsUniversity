﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObserverLab.Widgets
{
    class PWN : iObserver
    {
        private string pwn;
        public void Display()
        {
            Console.WriteLine("*СИРЕНА*: {0}", pwn);
            Console.WriteLine("__________________________________");
        }

        public void Update(string SMS, string PWN, string TV)
        {
            pwn = PWN;
            Display();
        }
    }
}
