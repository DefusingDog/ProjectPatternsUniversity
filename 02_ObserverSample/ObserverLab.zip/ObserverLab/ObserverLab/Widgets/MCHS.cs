﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObserverLab.Widgets
{
    class MCHS : iMCHS
    {
        private List<iObserver> observers;
        private static Random rand;


        public MCHS()
        {
            rand = new Random();
            observers = new List<iObserver>();
        }

        public string get_weather_warning()
        {
            List<string> time = new List<string>
            {
                "9:00",
                "10:00",
                "11:00",
                "12:00",
                "13:00",
                "14:00",
                "15:00",
                "16:00",
                "17:00",
                "18:00",
                "19:00",
                "20:00",
                "21:00",
                "22:00"
            };
            List<string> place = new List<string>
            { 
                "Заволжском",
                "Дзержинском",
                "Кировском",
                "Красноперекопском",
                "Ленинском",
                "Фрунзенском"
            };
            List<string> main = new List<string>
            {                 
                "штормовое предупреждение",
                "крупный град",
                "сильный туман",
                "встреча с оффниками",
                "проливной дождь",
                "аномально низкая температура"
            };


            return "ВНИМАНИЕ! Около " + time[rand.Next(14)] + " в " + place[rand.Next(6)] + " р-не г.Ярославля ожидается " + main[rand.Next(6)]+". Будьте осторожны!";

        }

        public string get_test_warning()
        {
            return "У-у-у-у-у-у-у-у-у *проверка работы сирен*";
        }

        public string get_CHS_warning()
        {
            List<String> CHS = new List<string>
            {
                "Наводнение", "Радиационная опасность", "Химическая тревога", "Воздушная тревога", "Отбой воздушной тревоги"
            };
            return "ВНИМАНИЕ! " + CHS[rand.Next(5)] + "!";
        }

        public void notifyObservers()
        {
            string sms = get_weather_warning();
            string pwn;
            string tv;

            if (rand.Next(2)%2==0)
                pwn = get_test_warning();
            else
                pwn = get_CHS_warning();

            if (rand.Next(2) % 2 == 0)
                tv = get_test_warning();
            else
                tv = get_CHS_warning();

            foreach (iObserver observer in observers)
                observer.Update(sms, pwn, tv);
        }


        public void subObserver(iObserver observer)
        {
            observers.Add(observer);
        }


        public void desubObserver(iObserver observer)
        {
            observers.Remove(observer);
        }
    }
}
